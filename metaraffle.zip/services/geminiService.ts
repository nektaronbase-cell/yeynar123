import { GoogleGenAI } from "@google/genai";
import { Block } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateBlockCommentary = async (block: Block): Promise<string> => {
  try {
    const winnerEntry = block.entries.find(e => e.userId === block.winnerId);
    const winnerName = winnerEntry ? winnerEntry.username : 'Unknown';
    const potSize = block.totalPot;
    
    const prompt = `
      You are an excited esports-style announcer for a high-stakes crypto raffle called "RaffleCaster".
      Block #${block.id} just finished.
      Winner: ${winnerName}.
      Pot Won: $${(potSize * 0.9).toFixed(2)}.
      Total Volume: $${potSize}.
      
      Write a VERY short, hype-filled, one-sentence notification about this win. Use emojis.
      Example: "BOOM! UserX just shattered the pot taking home $2000! 🚀"
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Block completed! Waiting for the next round.";
  } catch (error) {
    console.error("Gemini commentary failed:", error);
    return `Block #${block.id} finalized. Winner: ${block.winnerId?.slice(0, 6)}...`;
  }
};