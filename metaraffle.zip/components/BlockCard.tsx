import React, { useMemo, useState } from 'react';
import { Block } from '../types';
import { MAX_POT_SIZE, MAX_BLOCK_DURATION_MS, ENTRY_COST, MAX_ENTRIES_PER_USER_PER_BLOCK } from '../constants';
import { Users, Clock, Trophy, Zap, Wallet, Share2, Check } from 'lucide-react';

interface BlockCardProps {
  block: Block;
  currentTime: number;
  onEnter: (amount: number) => void;
  onConnect: () => void;
  userBalance: number;
  walletAddress: string | null;
  isProcessing: boolean;
}

export const BlockCard: React.FC<BlockCardProps> = ({ 
  block, 
  currentTime, 
  onEnter, 
  onConnect,
  userBalance, 
  walletAddress,
  isProcessing
}) => {
  const [showCopied, setShowCopied] = useState(false);
  const timeLeft = Math.max(0, (block.startTime + MAX_BLOCK_DURATION_MS) - currentTime);
  const percentTime = Math.min(100, ((MAX_BLOCK_DURATION_MS - timeLeft) / MAX_BLOCK_DURATION_MS) * 100);
  const percentPot = Math.min(100, (block.totalPot / MAX_POT_SIZE) * 100);

  const myEntriesCount = useMemo(() => {
    if (!walletAddress) return 0;
    return block.entries.filter(e => e.userId.toLowerCase() === walletAddress.toLowerCase()).length;
  }, [block.entries, walletAddress]);

  const canEnter = walletAddress && myEntriesCount < MAX_ENTRIES_PER_USER_PER_BLOCK && block.status === 'active';
  
  const formatTime = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    return `${h}h ${m}m ${s}s`;
  };

  const handleShare = async () => {
    const details = [
      `💰 Pot: $${block.totalPot.toLocaleString()}`,
      block.winnerId ? `👑 Winner: ${block.winnerId.slice(0, 6)}...` : `⏳ Ends in: ${formatTime(timeLeft)}`,
      `🎲 Entries: ${block.entries.length}`
    ].filter(Boolean).join('\n');

    const text = `🔥 RaffleCaster Block #${block.id}\n${details}\n\nJoin the action at ${window.location.origin}`;

    if (navigator.share && /mobile|android|iphone/i.test(navigator.userAgent)) {
      try {
        await navigator.share({
          title: `RaffleCaster Block #${block.id}`,
          text: text,
          url: window.location.href
        });
      } catch (err) {
        // Share cancelled
      }
    } else {
      try {
        await navigator.clipboard.writeText(text);
        setShowCopied(true);
        setTimeout(() => setShowCopied(false), 2000);
      } catch (err) {
        console.error('Failed to copy');
      }
    }
  };

  return (
    <div className="relative group rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-xl overflow-hidden">
      {/* Background Glow */}
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
      
      <div className="flex justify-between items-start mb-6 relative z-10">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-neon-blue to-neon-purple">
                Block #{block.id}
              </span>
              {block.status === 'active' && (
                <span className="flex h-3 w-3 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                </span>
              )}
            </h2>
            <button 
              onClick={handleShare}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all border border-slate-700 hover:border-slate-600 group/btn"
              title="Share Block"
            >
              {showCopied ? <Check size={16} className="text-green-400" /> : <Share2 size={16} />}
            </button>
          </div>
          <p className="text-slate-400 text-sm mt-1">
            Min Entry: <span className="text-white font-mono">${ENTRY_COST} USDC</span>
          </p>
        </div>
        <div className="text-right">
          <div className="text-3xl font-mono font-bold text-white tracking-tighter">
            ${block.totalPot.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 uppercase tracking-widest">Current Pot</div>
        </div>
      </div>

      {/* Progress Bars */}
      <div className="space-y-6 relative z-10">
        
        {/* Pot Progress */}
        <div>
          <div className="flex justify-between text-xs text-slate-400 mb-1">
            <span className="flex items-center gap-1"><Zap size={12} /> Pot Limit</span>
            <span>{Math.round(percentPot)}%</span>
          </div>
          <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-green-400 to-emerald-600 transition-all duration-300 ease-out"
              style={{ width: `${percentPot}%` }}
            />
          </div>
          <div className="flex justify-between text-xs mt-1 text-slate-500">
            <span>$0</span>
            <span>${MAX_POT_SIZE}</span>
          </div>
        </div>

        {/* Time Progress */}
        <div>
          <div className="flex justify-between text-xs text-slate-400 mb-1">
            <span className="flex items-center gap-1"><Clock size={12} /> Time Remaining</span>
            <span className="font-mono text-neon-blue">{formatTime(timeLeft)}</span>
          </div>
          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-1000 ease-linear ${timeLeft < 300000 ? 'bg-red-500 animate-pulse' : 'bg-blue-500'}`}
              style={{ width: `${100 - percentTime}%` }}
            />
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4 my-6 relative z-10">
        <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-700/50 flex flex-col items-center justify-center">
          <Users size={16} className="text-slate-400 mb-1" />
          <span className="text-lg font-bold text-white">{block.entries.length}</span>
          <span className="text-xs text-slate-400">Total Entries</span>
        </div>
        <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-700/50 flex flex-col items-center justify-center">
          <Trophy size={16} className="text-amber-400 mb-1" />
          <span className="text-lg font-bold text-white">{(block.totalPot * 0.9).toFixed(0)}</span>
          <span className="text-xs text-slate-400">Est. Winner Take</span>
        </div>
      </div>

      {/* Action Area */}
      <div className="relative z-10 mt-6">
        {block.status === 'processing' ? (
          <button disabled className="w-full py-4 rounded-xl bg-slate-800 text-slate-400 font-bold cursor-not-allowed animate-pulse border border-slate-700">
            Calculating Winner...
          </button>
        ) : !walletAddress ? (
          <button
            onClick={onConnect}
            className="w-full py-4 rounded-xl font-bold text-lg tracking-wide transition-all duration-200 transform active:scale-95 shadow-lg border-b-4 bg-slate-700 text-white border-slate-900 hover:bg-slate-600 flex items-center justify-center gap-2"
          >
            <Wallet size={20} /> Connect Wallet
          </button>
        ) : (
          <div className="flex flex-col gap-2">
             <button
              onClick={() => onEnter(ENTRY_COST)}
              disabled={!canEnter || userBalance < ENTRY_COST || isProcessing}
              className={`w-full py-4 rounded-xl font-bold text-lg tracking-wide transition-all duration-200 transform active:scale-95 shadow-lg border-b-4 flex items-center justify-center gap-2
                ${!canEnter || userBalance < ENTRY_COST || isProcessing
                  ? 'bg-slate-800 text-slate-500 border-slate-900 cursor-not-allowed' 
                  : 'bg-gradient-to-r from-neon-blue to-blue-600 text-white border-blue-800 hover:shadow-neon-blue/20 hover:brightness-110'
                }`}
            >
              {isProcessing ? (
                <span className="animate-pulse">Confirming Transaction...</span>
              ) : userBalance < ENTRY_COST ? (
                "Insufficient Balance"
              ) : myEntriesCount >= MAX_ENTRIES_PER_USER_PER_BLOCK ? (
                "Max Entries Reached"
              ) : (
                "ENTER RAFFLE (2 USDC)"
              )}
            </button>
            <div className="text-center text-xs text-slate-500">
              My Entries: <span className="text-white">{myEntriesCount}</span> / {MAX_ENTRIES_PER_USER_PER_BLOCK}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
