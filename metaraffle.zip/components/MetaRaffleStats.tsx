import React from 'react';
import { MetaRaffleState, Block } from '../types';
import { META_RAFFLE_THRESHOLD } from '../constants';
import { Gift, TrendingUp } from 'lucide-react';

interface MetaRaffleStatsProps {
  metaState: MetaRaffleState;
  currentBlockId: number;
}

export const MetaRaffleStats: React.FC<MetaRaffleStatsProps> = ({ metaState, currentBlockId }) => {
  const blocksRemaining = META_RAFFLE_THRESHOLD - (metaState.blocksCompleted % META_RAFFLE_THRESHOLD);
  const progress = ((META_RAFFLE_THRESHOLD - blocksRemaining) / META_RAFFLE_THRESHOLD) * 100;
  
  // Sort top contributors
  const sortedContributors = Array.from(metaState.topContributors.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5); // Show top 5 preview

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 h-full flex flex-col">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-amber-500/10 rounded-lg text-amber-500">
          <Gift size={24} />
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">Meta-Raffle</h3>
          <p className="text-xs text-slate-400">100 USDC Bonus every 100 Blocks</p>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex justify-between text-sm mb-2">
          <span className="text-slate-300">Cycle Progress</span>
          <span className="text-neon-blue font-mono">{META_RAFFLE_THRESHOLD - blocksRemaining} / {META_RAFFLE_THRESHOLD}</span>
        </div>
        <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
          <div 
            className="bg-gradient-to-r from-amber-400 to-orange-600 h-full transition-all duration-500" 
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-xs text-slate-500 mt-2 text-center">
          Top 100 entered into a free draw after every 100 blocks.
        </p>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col">
        <h4 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
          <TrendingUp size={14} /> Top Contributors (Live)
        </h4>
        <div className="space-y-2 overflow-y-auto pr-1 flex-1 custom-scrollbar">
          {sortedContributors.length === 0 ? (
            <div className="text-center text-slate-600 text-sm py-4">No activity yet</div>
          ) : (
            sortedContributors.map(([userId, amount], idx) => (
              <div key={userId} className="flex justify-between items-center text-sm p-2 bg-slate-800/40 rounded-lg">
                <div className="flex items-center gap-2">
                  <span className={`w-5 h-5 flex items-center justify-center rounded-full text-xs font-bold ${idx === 0 ? 'bg-yellow-500 text-black' : 'bg-slate-700 text-slate-400'}`}>
                    {idx + 1}
                  </span>
                  <span className="text-slate-200 truncate max-w-[100px]">{userId.startsWith('user-main') ? 'YOU' : userId}</span>
                </div>
                <span className="font-mono text-emerald-400">${amount}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};