import React from 'react';
import { Block } from '../types';
import { CheckCircle2, Bot } from 'lucide-react';

interface HistoryLogProps {
  completedBlocks: Block[];
}

export const HistoryLog: React.FC<HistoryLogProps> = ({ completedBlocks }) => {
  // Show most recent first
  const sorted = [...completedBlocks].sort((a, b) => b.id - a.id);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 h-full flex flex-col">
      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <CheckCircle2 size={20} className="text-green-500" />
        Block History
      </h3>
      
      <div className="flex-1 overflow-y-auto pr-2 space-y-3 custom-scrollbar">
        {sorted.length === 0 ? (
          <div className="text-center text-slate-600 py-8">No completed blocks yet.</div>
        ) : (
          sorted.map(block => (
            <div key={block.id} className="bg-slate-800/30 p-4 rounded-xl border border-slate-700/30 hover:bg-slate-800/50 transition-colors">
              <div className="flex justify-between items-start mb-2">
                <span className="text-neon-purple font-bold text-sm">Block #{block.id}</span>
                <span className="text-xs text-slate-500">{new Date(block.endTime || 0).toLocaleTimeString()}</span>
              </div>
              
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center gap-2">
                   <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-500 to-purple-500 flex items-center justify-center text-xs font-bold">
                      {block.winnerId?.slice(0, 2).toUpperCase()}
                   </div>
                   <div className="flex flex-col">
                     <span className="text-sm font-medium text-white">Winner</span>
                     <span className="text-xs text-slate-400 flex items-center gap-1">
                       {block.winnerId?.startsWith('bot') && <Bot size={10} />}
                       {block.winnerId}
                     </span>
                   </div>
                </div>
                <div className="text-right">
                  <div className="text-emerald-400 font-bold font-mono">
                    +${block.distribution?.winnerAmount.toFixed(0)}
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Pot: ${block.totalPot}
                  </div>
                </div>
              </div>

              {block.aiCommentary && (
                 <div className="mt-2 p-2 bg-indigo-900/20 rounded border border-indigo-500/20 text-xs text-indigo-200 italic">
                    "{block.aiCommentary}"
                 </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};